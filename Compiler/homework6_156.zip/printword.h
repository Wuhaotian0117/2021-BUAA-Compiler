//
// Created by wuhaotian on 2021/10/15.
//

#ifndef HOMEWORK3P_PRINTWORD_H
#define HOMEWORK3P_PRINTWORD_H

#include <iostream>
#include <string>
using namespace std;
void printword(int fsymbol, string fword, int fline);
string symstring(int fsymbol, string fword, int fline);

#endif //HOMEWORK3P_PRINTWORD_H
